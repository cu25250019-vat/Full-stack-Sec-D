const express = require("express");
const app = express();
app.use(express.json());
let students=[]; let nextId=1;
function isValidStudent(data){return data&&typeof data.name==="string"&&data.name.trim()!==""&&typeof data.email==="string"&&data.email.trim()!==""&&typeof data.age==="number"&&data.age>0;}
app.post("/students",(req,res)=>{const {name,email,age}=req.body; if(!isValidStudent({name,email,age})) return res.status(400).json({error:"Invalid input"}); if(students.find(s=>s.email===email)) return res.status(409).json({error:"Email already exists"}); const student={id:nextId++,name,email,age}; students.push(student); res.status(201).json(student);});
app.get('/students',(req,res)=>{const {minAge}=req.query; if(minAge) return res.json(students.filter(s=>s.age>=Number(minAge))); res.json(students);});
app.get('/students/:id',(req,res)=>{const s=students.find(x=>x.id===Number(req.params.id)); if(!s) return res.status(404).json({error:'Student not found'}); res.json(s);});
app.delete('/students/:id',(req,res)=>{const i=students.findIndex(x=>x.id===Number(req.params.id)); if(i===-1) return res.status(404).json({error:'Student not found'}); students.splice(i,1); res.status(204).send();});
app.listen(3000); module.exports=app;