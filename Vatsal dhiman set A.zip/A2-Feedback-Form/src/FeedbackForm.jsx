import React,{useState} from "react";
export default function FeedbackForm(){
const [name,setName]=useState("");
const [email,setEmail]=useState("");
const [rating,setRating]=useState("");
const [comment,setComment]=useState("");
const [submitted,setSubmitted]=useState(false);
const validName=name.trim()!=="";
const validEmail=/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
const validRating=rating!=="";
const submit=(e)=>{e.preventDefault(); if(validName&&validEmail&&validRating) setSubmitted(true);};
if(submitted) return <p data-testid="success-msg">Thank you, {name}! Feedback submitted.</p>;
return (<form onSubmit={submit}><input data-testid="name-input" value={name} onChange={e=>setName(e.target.value)}/>{!validName&&<p data-testid="name-error">Name is required</p>}<input data-testid="email-input" value={email} onChange={e=>setEmail(e.target.value)}/>{email&&!validEmail&&<p data-testid="email-error">Invalid email</p>}<select data-testid="rating-select" value={rating} onChange={e=>setRating(e.target.value)}><option value=""></option><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></select>{!validRating&&<p data-testid="rating-error">Rating is required</p>}<textarea data-testid="comment-input" maxLength={200} value={comment} onChange={e=>setComment(e.target.value)}/><p data-testid="comment-count">{comment.length}/200</p><button data-testid="submit-btn">Submit</button></form>);
}